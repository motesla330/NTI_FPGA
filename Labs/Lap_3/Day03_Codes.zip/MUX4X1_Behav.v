module MUX4X1_Behav
(
  input wire A,
  input wire B,
  input wire C,
  input wire D,  
  input wire [1:0] S,
  
  output reg F
);
 
  // Behav 
  always@(*)
    begin
	  case(S)
	   2'b00: F = A;
		2'b01: F = B;
		2'b10: F = 1'b0;
		2'b11: F = 1'b1;
	    default: F = A;
	  endcase
	end

 /*
  // Behav 
  always@(*)
    begin
	  case(S)
	    2'b00: F = A;
		2'b01: F = B;
		2'b10: F = C;
		2'b11: F = D;
	    default: F = A;
	  endcase
	end
*/
/*
  always@(*)
    begin
	  if(S == 2'b00)
	    begin
	      F = A;
		end
	  else if(S == 2'b01) 
	    F = B;
	  else if(S == 2'b10)
	    F = C;
	  else 
	    F = D;
	end
  */
endmodule