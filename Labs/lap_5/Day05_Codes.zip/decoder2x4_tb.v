`timescale 1ns / 1ps
module decoder2x4_tb;
  // TB parameters
  localparam N_tb = 2;
  
  //Tb signals
  reg [($clog2(N_tb))-1:0] A;
  reg en;
  wire [N_tb-1:0] F;
  
  // Module instantiation
  decoder2x4 
  #( .N(N_tb) )  
  decod
  (
  .A(A),
  .en(en),
  .F(F)
  );  
  
  // Stimulus generation
  initial
    begin
	$dumpfile("dump.vcd");
	$dumpvars(0, decoder2x4_tb);
	
	en = 1'b0;
	A = 2'b01;
	#10;
	
	en = 1'b0;
	A = 2'b11;
	#10;
	
	en = 1'b1;
	A = 2'b00;
	#10;

	en = 1'b1;
	A = 2'b01;
	#10;	

	en = 1'b1;
	A = 2'b10;
	#10;	

	en = 1'b1;
	A = 2'b11;
	
	#20;
	$stop;
	end

endmodule