module MUX4X1_Data
(
  input wire A,
  input wire B,
  input wire C,
  input wire D,  
  input wire [1:0] S,
  
  output wire F
);
  
  // Data flow
  assign F = (S == 2'b00)? A:
             (S == 2'b01)? B:
             (S == 2'b10)? C: D;
/*
  // Behav 
  always@(*)
    begin
	  case(S)
	    2'b00: F = A;
		2'b01: F = B;
		2'b10: F = C;
		2'b11: F = D;
	    default: F = A;
	  endcase
	end

  always@(*)
    begin
	  if(S == 2'b00)
	    begin
	      F = A;
		end
	  else if(S == 2'b01) 
	    F = B;
	  else if(S == 2'b10)
	    F = C;
	  else 
	    F = D;
	end
	
  // Struct
  wire M1_out;
  wire M2_out;
  
  MUX2X1 M1 (.A(A) , .B(B), .S(S[0]), .F(M1_out));
  MUX2X1 M2 (.A(C) , .B(D), .S(S[0]), .F(M2_out));
  MUX2X1 M3 (.A(M1_out) , .B(M2_out), .S(S[1]), .F(F));
  
  // GL
  wire or0;
  wire or1;
  wire or2;
  wire or3;
  
  and a0 (or0, a, !s[0], !s[1]);
  and a1 (or1, b, !s[0], s[1]);
  and a2 (or2, c, s[0], !s[1]);
  and a3 (or3, d, s[0], s[1]);
  
  or or0 (y, or0, or1, or2, or3);
  */
endmodule