module MUX4X1_Struct
(
  input wire A,
  input wire B,
  input wire C,
  input wire D,  
  input wire [1:0] S,
  
  output wire F
);
	
  // Struct
  wire M1_out;
  wire M2_out;
  
  MUX2X1 M1 (.A(A) , .B(B), .S(S[0]), .F(M1_out));
  MUX2X1 M2 (.A(C) , .B(D), .S(S[0]), .F(M2_out));
  MUX2X1 M3 (.A(M1_out) , .B(M2_out), .S(S[1]), .F(F));
  
endmodule