`timescale 1ns / 1ps
module MUX4X1_ALL_tb;

 //TB signals 
  reg A;
  reg B;
  reg C;
  reg D;
  reg [1:0] S;
  
  wire F_GL;
  wire F_Struct;
  wire F_Behav;
  wire F_Data;
  
  // Modules instantiation
  MUX4X1_GL M_GL
  (
    .A(A),
    .B(B),
    .C(C),
	.D(D),
	.S(S),
	.F(F_GL)
  );

  MUX4X1_Struct M_Struct
  (
    .A(A),
    .B(B),
    .C(C),
	.D(D),
	.S(S),
	.F(F_Struct)
  );

  MUX4X1_Behav M_Behave
  (
    .A(A),
    .B(B),
    .C(C),
	.D(D),
	.S(S),
	.F(F_Behav)
  );

  MUX4X1_Data M_Data 
  (
    .A(A),
    .B(B),
    .C(C),
	.D(D),
	.S(S),
	.F(F_Data)
  );  
  
  
  // Stimuls generation
  initial
    begin
	  A = 1'b1; B = 1'b0; C = 1'b0; D = 1'b0; S = 2'b00; 
	  #10;
	  
	  A = 1'b1; B = 1'b0; C = 1'b0; D = 1'b0; S = 2'b01; 
	  #10;

	  A = 1'b1; B = 1'b0; C = 1'b0; D = 1'b0; S = 2'b10; 
	  #10;	  
	  
	  A = 1'b1; B = 1'b0; C = 1'b0; D = 1'b0; S = 2'b11; 
	  #10;	
	  
	  $stop;
	end
  
endmodule