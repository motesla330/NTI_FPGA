module MUX4X1_ALL
(
  input wire A,
  input wire B,
  input wire C,
  input wire D,  
  input wire [1:0] S,
  
  output wire F_GL,
  output wire F_Struct,
  output wire F_Behav,
  output wire F_Data  
);

  MUX4X1_GL M_GL
  (
    .A(A),
    .B(B),
    .C(C),
	.D(D),
	.S(S),
	.F(F_GL)
  );

  MUX4X1_Struct M_Struct
  (
    .A(A),
    .B(B),
    .C(C),
	.D(D),
	.S(S),
	.F(F_Struct)
  );

  MUX4X1_Behav M_Behave
  (
    .A(A),
    .B(B),
    .C(C),
	.D(D),
	.S(S),
	.F(F_Behav)
  );

  MUX4X1_Data M_Data 
  (
    .A(A),
    .B(B),
    .C(C),
	.D(D),
	.S(S),
	.F(F_Data)
  );  
  
endmodule