module MUX4X1_GL
(
  input wire A,
  input wire B,
  input wire C,
  input wire D,  
  input wire [1:0] S,
  
  output wire F
);
  
  // GL
  wire or0;
  wire or1;
  wire or2;
  wire or3;
  
  and a0 (or0, A, !S[0], !S[1]);
  and a1 (or1, B,  S[0], !S[1]);
  and a2 (or2, C, !S[0], S[1]);
  and a3 (or3, D,  S[0], S[1]);
  
  or or_g_0 (F, or0, or1, or2, or3);
  
endmodule