`timescale 1ns / 1ps
module d_ff_tb;
  
  // TB signals
  reg D;
  reg clock;
  reg reset;  // Active High reset
  wire Q; 

  d_ff D0
  (
    .D(D),
    .clock(clock),
    .reset(reset),  // Active High reset
    .Q(Q)
  );

  
  
  
  initial 
    begin
	  D = 1'b1;
	  reset = 1'b0;
	  
	  
	  
	  
	end

endmodule