`default_nettype none
`timescale 1ns / 1ps

module decoder2x4 #
( 
  parameter N = 4
)
(
  input wire [($clog2(N))-1:0] A,
  input wire en, 
  output reg [N-1:0] F
);

  always@(*)
    begin
      //initial value
	  F = {N{1'b0}};
	  if(en)
	    begin
          F[A] = 1'b1;
		end
	end

endmodule